import { useState, useEffect, useCallback } from 'react'

interface Card {
  id: number
  emoji: string
  isFlipped: boolean
  isMatched: boolean
}

interface GameStats {
  moves: number
  matches: number
  bestScore: number
  time: number
}

const EMOJIS = ['🎮', '🎯', '🎲', '🎨', '🎭', '🎪', '🎬', '🎰', '🎳', '🏆', '🎁', '🎀']

const shuffleCards = (): Card[] => {
  const selectedEmojis = EMOJIS.slice(0, 8)
  const doubledEmojis = [...selectedEmojis, ...selectedEmojis]
  
  const shuffled = doubledEmojis
    .map((emoji, index) => ({
      id: index,
      emoji,
      isFlipped: false,
      isMatched: false
    }))
    .sort(() => Math.random() - 0.5)
  
  return shuffled
}

export default function App() {
  const [cards, setCards] = useState<Card[]>([])
  const [flippedCards, setFlippedCards] = useState<number[]>([])
  const [stats, setStats] = useState<GameStats>({
    moves: 0,
    matches: 0,
    bestScore: Infinity,
    time: 0
  })
  const [isPlaying, setIsPlaying] = useState(false)
  const [gameWon, setGameWon] = useState(false)
  const [isPaused, setIsPaused] = useState(false)

  const initializeGame = useCallback(() => {
    setCards(shuffleCards())
    setFlippedCards([])
    setStats(prev => ({
      moves: 0,
      matches: 0,
      bestScore: prev.bestScore,
      time: 0
    }))
    setIsPlaying(true)
    setGameWon(false)
    setIsPaused(false)
  }, [])

  useEffect(() => {
    initializeGame()
  }, [initializeGame])

  useEffect(() => {
    let interval: NodeJS.Timeout
    
    if (isPlaying && !isPaused && !gameWon) {
      interval = setInterval(() => {
        setStats(prev => ({ ...prev, time: prev.time + 1 }))
      }, 1000)
    }
    
    return () => clearInterval(interval)
  }, [isPlaying, isPaused, gameWon])

  useEffect(() => {
    if (stats.matches === 8 && isPlaying) {
      setGameWon(true)
      setIsPlaying(false)
      
      if (stats.moves < stats.bestScore) {
        setStats(prev => ({ ...prev, bestScore: stats.moves }))
        localStorage.setItem('memoryBestScore', stats.moves.toString())
      }
    }
  }, [stats.matches, stats.moves, stats.bestScore, isPlaying])

  useEffect(() => {
    const savedBestScore = localStorage.getItem('memoryBestScore')
    if (savedBestScore) {
      setStats(prev => ({ ...prev, bestScore: parseInt(savedBestScore) }))
    }
  }, [])

  const handleCardClick = (id: number) => {
    if (!isPlaying || isPaused || gameWon) return
    if (flippedCards.length >= 2) return
    
    const card = cards.find(c => c.id === id)
    if (!card || card.isFlipped || card.isMatched) return

    const newCards = cards.map(card =>
      card.id === id ? { ...card, isFlipped: true } : card
    )
    setCards(newCards)

    const newFlippedCards = [...flippedCards, id]
    setFlippedCards(newFlippedCards)

    if (newFlippedCards.length === 2) {
      setStats(prev => ({ ...prev, moves: prev.moves + 1 }))

      const [firstId, secondId] = newFlippedCards
      const firstCard = newCards.find(c => c.id === firstId)
      const secondCard = newCards.find(c => c.id === secondId)

      if (firstCard && secondCard && firstCard.emoji === secondCard.emoji) {
        setTimeout(() => {
          setCards(prev =>
            prev.map(card =>
              card.id === firstId || card.id === secondId
                ? { ...card, isMatched: true }
                : card
            )
          )
          setStats(prev => ({ ...prev, matches: prev.matches + 1 }))
          setFlippedCards([])
        }, 500)
      } else {
        setTimeout(() => {
          setCards(prev =>
            prev.map(card =>
              card.id === firstId || card.id === secondId
                ? { ...card, isFlipped: false }
                : card
            )
          )
          setFlippedCards([])
        }, 1000)
      }
    }
  }

  const formatTime = (seconds: number): string => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}:${secs.toString().padStart(2, '0')}`
  }

  const getDifficulty = () => {
    if (stats.moves <= 20) return { level: '🟢 Oson', color: 'text-green-500' }
    if (stats.moves <= 30) return { level: '🟡 O\'rta', color: 'text-yellow-500' }
    return { level: '🔴 Qiyin', color: 'text-red-500' }
  }

  const difficulty = getDifficulty()

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 p-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-6">
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-2 drop-shadow-lg">
            🎯 Memory Puzzle
          </h1>
          <p className="text-blue-200 text-sm md:text-base">
            Kartalarni juftlab toping!
          </p>
        </div>

        {/* Stats Bar */}
        <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-4 mb-6 shadow-xl">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center">
              <div className="text-blue-300 text-xs md:text-sm">Harakat</div>
              <div className="text-2xl md:text-3xl font-bold text-white">{stats.moves}</div>
            </div>
            <div className="text-center">
              <div className="text-green-300 text-xs md:text-sm">Juftlik</div>
              <div className="text-2xl md:text-3xl font-bold text-white">
                {stats.matches}/8
              </div>
            </div>
            <div className="text-center">
              <div className="text-yellow-300 text-xs md:text-sm">Vaqt</div>
              <div className="text-2xl md:text-3xl font-bold text-white">
                {formatTime(stats.time)}
              </div>
            </div>
            <div className="text-center">
              <div className="text-purple-300 text-xs md:text-sm">Eng yaxshi</div>
              <div className="text-2xl md:text-3xl font-bold text-white">
                {stats.bestScore === Infinity ? '-' : stats.bestScore}
              </div>
            </div>
          </div>
        </div>

        {/* Difficulty & Controls */}
        <div className="flex flex-wrap justify-center gap-3 mb-6">
          <div className={`px-4 py-2 rounded-full bg-white/10 backdrop-blur-sm ${difficulty.color} font-semibold`}>
            {difficulty.level}
          </div>
          <button
            onClick={() => setIsPaused(!isPaused)}
            disabled={!isPlaying || gameWon}
            className="px-4 py-2 rounded-full bg-yellow-500/80 hover:bg-yellow-500 text-white font-semibold transition-all disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isPaused ? '▶️ Davom etish' : '⏸️ Pauza'}
          </button>
          <button
            onClick={initializeGame}
            className="px-4 py-2 rounded-full bg-green-500/80 hover:bg-green-500 text-white font-semibold transition-all"
          >
            🔄 Qayta o'ynash
          </button>
        </div>

        {/* Game Board */}
        <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-4 md:p-6 shadow-xl">
          <div className="grid grid-cols-4 gap-2 md:gap-3">
            {cards.map((card) => (
              <button
                key={card.id}
                onClick={() => handleCardClick(card.id)}
                disabled={!isPlaying || isPaused || card.isFlipped || card.isMatched || gameWon}
                className={`
                  aspect-square rounded-xl text-3xl md:text-5xl font-bold
                  transition-all duration-300 transform
                  ${card.isFlipped || card.isMatched
                    ? 'bg-gradient-to-br from-yellow-400 to-orange-500 rotate-y-180'
                    : 'bg-gradient-to-br from-blue-500 to-purple-600 hover:scale-105'
                  }
                  ${card.isMatched ? 'ring-4 ring-green-400 scale-105' : ''}
                  ${!card.isFlipped && !card.isMatched ? 'hover:shadow-lg' : ''}
                  disabled:cursor-default
                  shadow-lg
                `}
                style={{
                  perspective: '1000px',
                }}
              >
                <div className="w-full h-full flex items-center justify-center">
                  {(card.isFlipped || card.isMatched) ? card.emoji : '❓'}
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Win Modal */}
        {gameWon && (
          <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50 p-4">
            <div className="bg-gradient-to-br from-purple-800 to-blue-800 rounded-3xl p-8 max-w-md w-full text-center shadow-2xl transform animate-bounce">
              <div className="text-6xl mb-4">🏆</div>
              <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
                Tabriklaymiz!
              </h2>
              <p className="text-blue-200 mb-6">
                Siz o'yinni yutdingiz!
              </p>
              <div className="grid grid-cols-2 gap-4 mb-6">
                <div className="bg-white/10 rounded-xl p-4">
                  <div className="text-blue-300 text-sm">Harakat</div>
                  <div className="text-2xl font-bold text-white">{stats.moves}</div>
                </div>
                <div className="bg-white/10 rounded-xl p-4">
                  <div className="text-yellow-300 text-sm">Vaqt</div>
                  <div className="text-2xl font-bold text-white">{formatTime(stats.time)}</div>
                </div>
              </div>
              {stats.moves <= stats.bestScore && stats.moves > 0 && (
                <div className="bg-green-500/20 border-2 border-green-500 rounded-xl p-3 mb-6">
                  <div className="text-green-400 font-bold">🎉 Yangi rekord!</div>
                </div>
              )}
              <button
                onClick={initializeGame}
                className="w-full py-3 rounded-xl bg-gradient-to-r from-green-500 to-blue-500 hover:from-green-600 hover:to-blue-600 text-white font-bold text-lg transition-all transform hover:scale-105"
              >
                Qayta o'ynash 🎮
              </button>
            </div>
          </div>
        )}

        {/* Pause Modal */}
        {isPaused && (
          <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50 p-4">
            <div className="bg-gradient-to-br from-purple-800 to-blue-800 rounded-3xl p-8 max-w-md w-full text-center shadow-2xl">
              <div className="text-6xl mb-4">⏸️</div>
              <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
                O'yin to'xtatildi
              </h2>
              <button
                onClick={() => setIsPaused(false)}
                className="w-full py-3 rounded-xl bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600 text-white font-bold text-lg transition-all transform hover:scale-105"
              >
                Davom etish ▶️
              </button>
            </div>
          </div>
        )}

        {/* Instructions */}
        <div className="mt-6 bg-white/10 backdrop-blur-lg rounded-2xl p-4 text-center">
          <p className="text-blue-200 text-sm">
            💡 <strong>Maslahat:</strong> Kartalarning joylashuvini eslang va bir xil emojili juftliklarni toping!
          </p>
        </div>

        {/* Footer */}
        <div className="mt-6 text-center text-blue-300 text-sm">
          <p>📱 Mobil va kompyuter uchun moslashtirilgan</p>
        </div>
      </div>
    </div>
  )
}
